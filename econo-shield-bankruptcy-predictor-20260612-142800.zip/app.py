from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from econoshield.data_loader import load_macro_data, read_transaction_upload
from econoshield.risk_engine import (
    FinancialSnapshot,
    calculate_snapshot,
    clean_money,
    inventory_total,
    procedural_actions,
    summarize_macro,
)


st.set_page_config(
    page_title="Econo-Shield Bankruptcy Predictor",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded",
)


def rupiah(value: float) -> str:
    return f"Rp {value:,.0f}".replace(",", ".")


def pct(value: float) -> str:
    return f"{value * 100:.1f}%"


st.markdown(
    """
    <style>
    .block-container {padding-top: 1.25rem; padding-bottom: 2rem;}
    div[data-testid="stMetric"] {background: #F8FAFC; border: 1px solid #E2E8F0; padding: 14px 16px; border-radius: 8px;}
    .risk-banner {padding: 16px 18px; border-radius: 8px; color: white; margin-bottom: 16px;}
    .small-note {font-size: 0.9rem; color: #475569;}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("Econo-Shield Bankruptcy Predictor")

macro_upload = st.sidebar.file_uploader(
    "Upload dataset makro CSV opsional",
    type=["csv"],
    help="Kolom wajib: year, month_num, month, inflation_mtm, bi_rate.",
)

macro_df = load_macro_data(macro_upload)
macro = summarize_macro(macro_df)

st.sidebar.header("Simulasi Tekanan")
persona = st.sidebar.radio("Profil", ["Individu", "UMKM"], horizontal=True)
income_shock = st.sidebar.slider("Penurunan pemasukan", 0, 80, 20, step=5)
extra_rate_shock = st.sidebar.slider("Tambahan tekanan bunga", 0.0, 5.0, 1.0, step=0.25)
macro["latest_bi_rate"] += extra_rate_shock

left, right = st.columns([0.58, 0.42])

with left:
    st.subheader("Input Finansial")
    c1, c2 = st.columns(2)
    with c1:
        income_label = "Penjualan Bulanan" if persona == "UMKM" else "Pendapatan Bulanan"
        monthly_income = st.number_input(income_label, min_value=0, value=15_000_000 if persona == "UMKM" else 8_000_000, step=500_000)
        fixed_expense = st.number_input("Pengeluaran Tetap", min_value=0, value=6_000_000 if persona == "UMKM" else 3_500_000, step=250_000)
        variable_expense = st.number_input("Pengeluaran Variabel / HPP", min_value=0, value=5_000_000 if persona == "UMKM" else 2_000_000, step=250_000)
        monthly_debt_payment = st.number_input("Cicilan per Bulan", min_value=0, value=1_500_000, step=250_000)
    with c2:
        liquid_assets = st.number_input("Kas / Tabungan / Aset Liquid", min_value=0, value=20_000_000, step=500_000)
        investments = st.number_input("Investasi", min_value=0, value=5_000_000, step=500_000)
        total_debt = st.number_input("Total Utang", min_value=0, value=12_000_000, step=500_000)
        physical_assets = st.number_input("Aset Fisik", min_value=0, value=10_000_000 if persona == "UMKM" else 0, step=500_000)

    transaction_file = st.file_uploader("Upload CSV transaksi opsional", type=["csv"])
    if transaction_file:
        try:
            transactions = read_transaction_upload(transaction_file)
            income_from_csv = transactions.loc[transactions["type_clean"].str.contains("income|masuk|penjualan", regex=True), "amount_clean"].sum()
            expense_from_csv = transactions.loc[transactions["type_clean"].str.contains("expense|keluar|biaya|hpp", regex=True), "amount_clean"].abs().sum()
            st.info(f"Ringkasan CSV: pemasukan {rupiah(income_from_csv)}, pengeluaran {rupiah(expense_from_csv)}.")
        except Exception as exc:
            st.warning(str(exc))

with right:
    st.subheader("Inventaris UMKM")
    default_inventory = pd.DataFrame(
        [
            {"Nama Barang": "Produk A", "Jumlah Stok": 25, "HPP per Unit": 100_000},
            {"Nama Barang": "Produk B", "Jumlah Stok": 10, "HPP per Unit": 250_000},
            {"Nama Barang": "Produk C", "Jumlah Stok": 5, "HPP per Unit": 500_000},
        ]
    )
    if persona == "UMKM":
        inventory_df = st.data_editor(
            default_inventory,
            num_rows="dynamic",
            use_container_width=True,
            column_config={
                "Jumlah Stok": st.column_config.NumberColumn(min_value=0, step=1),
                "HPP per Unit": st.column_config.NumberColumn(min_value=0, step=10_000, format="Rp %d"),
            },
        )
        inv_value = inventory_total(inventory_df.to_dict("records"))
        st.metric("Total Nilai Inventaris", rupiah(inv_value))
    else:
        inventory_df = pd.DataFrame(columns=default_inventory.columns)
        inv_value = 0.0
        st.caption("Inventaris aktif saat profil UMKM dipilih.")

snapshot = FinancialSnapshot(
    monthly_income=clean_money(monthly_income),
    fixed_expense=clean_money(fixed_expense),
    variable_expense=clean_money(variable_expense),
    liquid_assets=clean_money(liquid_assets),
    investments=clean_money(investments),
    monthly_debt_payment=clean_money(monthly_debt_payment),
    total_debt=clean_money(total_debt),
    physical_assets=clean_money(physical_assets),
    inventory_value=clean_money(inv_value),
)

result = calculate_snapshot(snapshot, macro, income_shock)

st.markdown(
    f"<div class='risk-banner' style='background:{result['color']}'><b>Status: {result['status']}</b><br>"
    f"Skor kesehatan finansial {result['score']}/100 dengan skenario pemasukan turun {income_shock}%.</div>",
    unsafe_allow_html=True,
)

m1, m2, m3, m4 = st.columns(4)
m1.metric("Skor Kesehatan", f"{result['score']}/100")
m2.metric("Net Worth", rupiah(result["net_worth"]))
m3.metric("Cash Runway", f"{result['cash_runway_months']:.1f} bulan")
m4.metric("Rasio Cicilan", pct(result["debt_payment_ratio"]))

chart_df = pd.DataFrame(
    [
        {"Pilar": "Pemasukan", "Nilai": result["income_after_shock"]},
        {"Pilar": "Pengeluaran", "Nilai": result["stressed_expense"]},
        {"Pilar": "Aset", "Nilai": result["total_assets"]},
        {"Pilar": "Investasi", "Nilai": snapshot.investments},
        {"Pilar": "Utang", "Nilai": snapshot.total_debt},
    ]
)

tab1, tab2, tab3 = st.tabs(["Dashboard", "Data Makro", "Aturan Klasifikasi"])

with tab1:
    col_a, col_b = st.columns([0.58, 0.42])
    with col_a:
        fig = px.bar(
            chart_df,
            x="Pilar",
            y="Nilai",
            color="Pilar",
            color_discrete_sequence=["#2563EB", "#EF4444", "#059669", "#7C3AED", "#F97316"],
            text_auto=".2s",
        )
        fig.update_layout(showlegend=False, yaxis_title="Rupiah", xaxis_title=None, height=390, margin=dict(l=10, r=10, t=20, b=10))
        st.plotly_chart(fig, use_container_width=True)
    with col_b:
        st.write("Tindakan Prosedural")
        for action in procedural_actions(result):
            st.write(f"- {action}")
        st.divider()
        st.write("Ringkasan Rasio")
        st.write(f"- Surplus normal: **{rupiah(result['monthly_surplus'])}**")
        st.write(f"- Surplus setelah stress test: **{rupiah(result['stressed_surplus'])}**")
        st.write(f"- Debt to assets: **{pct(result['debt_to_assets'])}**")

with tab2:
    col_m1, col_m2 = st.columns(2)
    col_m1.metric("Inflasi bulanan terakhir", f"{macro['latest_inflation_mtm']:.2f}%")
    col_m2.metric("BI Rate + skenario", f"{macro['latest_bi_rate']:.2f}%")

    macro_fig = px.line(
        macro_df,
        x="period",
        y=["inflation_mtm", "bi_rate"],
        labels={"value": "Persen", "period": "Periode", "variable": "Indikator"},
        height=360,
    )
    macro_fig.update_layout(margin=dict(l=10, r=10, t=20, b=10))
    st.plotly_chart(macro_fig, use_container_width=True)
    st.dataframe(macro_df.tail(24), use_container_width=True, hide_index=True)

with tab3:
    st.write(
        """
        Resilient jika rasio cicilan aman, runway lebih dari 6 bulan, dan aset masih menutup tekanan inflasi.
        Near Crisis jika surplus sangat tipis, runway 1-3 bulan, cicilan mendekati 50% pemasukan, atau utang mulai dominan.
        Bankrupt/Krisis jika arus kas stres negatif, utang melebihi aset liquid, dan runway kurang dari 1 bulan.
        """
    )
    st.caption("Aplikasi ini decision-support tool, bukan nasihat keuangan profesional.")
