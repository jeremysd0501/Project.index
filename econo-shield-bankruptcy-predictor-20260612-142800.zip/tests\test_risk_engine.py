from econoshield.risk_engine import FinancialSnapshot, calculate_snapshot, inventory_total


MACRO = {
    "latest_inflation_mtm": 0.3,
    "avg_inflation_mtm": 0.3,
    "annualized_inflation": 3.6,
    "latest_bi_rate": 6.0,
}


def test_inventory_total():
    rows = [
        {"Jumlah Stok": 2, "HPP per Unit": 10_000},
        {"Jumlah Stok": 3, "HPP per Unit": 20_000},
    ]
    assert inventory_total(rows) == 80_000


def test_resilient_classification():
    snapshot = FinancialSnapshot(
        monthly_income=20_000_000,
        fixed_expense=4_000_000,
        variable_expense=3_000_000,
        liquid_assets=100_000_000,
        investments=30_000_000,
        monthly_debt_payment=1_000_000,
        total_debt=10_000_000,
    )
    result = calculate_snapshot(snapshot, MACRO, income_shock_pct=10)
    assert result["status"] == "Resilient / Tangguh"
    assert result["score"] >= 65


def test_bankrupt_classification():
    snapshot = FinancialSnapshot(
        monthly_income=5_000_000,
        fixed_expense=4_000_000,
        variable_expense=3_000_000,
        liquid_assets=1_000_000,
        investments=0,
        monthly_debt_payment=2_500_000,
        total_debt=30_000_000,
    )
    result = calculate_snapshot(snapshot, MACRO, income_shock_pct=20)
    assert result["status"] == "Bankrupt / Krisis"
    assert result["cash_runway_months"] < 1
