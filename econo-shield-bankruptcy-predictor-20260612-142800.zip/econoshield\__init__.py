"""Core package for Econo-Shield."""
