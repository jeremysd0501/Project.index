# Econo-Shield Bankruptcy Predictor

Econo-Shield adalah aplikasi web Streamlit untuk membantu individu dan UMKM mengevaluasi risiko krisis finansial atau kebangkrutan berbasis input kas, aset, utang, inventaris, inflasi, dan BI Rate.

## Fitur Utama

- Input finansial untuk profil Individu dan UMKM.
- Kalkulator inventaris UMKM: `Total Nilai Inventaris = jumlah stok x HPP per unit`.
- Bankruptcy / crisis risk classification engine dengan status:
  - `Resilient / Tangguh`
  - `Near Crisis / Waspada`
  - `Bankrupt / Krisis`
- Stress test penurunan pemasukan dan tekanan bunga.
- Dashboard grafik interaktif dengan Plotly.
- Upload CSV transaksi manual.
- Upload dataset makro CSV opsional.
- Data tidak disimpan ke database eksternal.

## Struktur Project

```text
.
├── app.py
├── econoshield/
│   ├── data_loader.py
│   └── risk_engine.py
├── data/
│   └── macro_indonesia_sample.csv
├── scripts/
│   └── prepare_macro_data.py
├── tests/
│   └── test_risk_engine.py
├── requirements.txt
└── README.md
```

## Library Yang Digunakan

Library utama:

- `streamlit`: framework web app Python terbaik untuk dashboard data cepat.
- `pandas`: membaca, membersihkan, dan mengolah data CSV/XLSX.
- `plotly`: grafik interaktif untuk dashboard finansial.
- `openpyxl`: engine pembaca file `.xlsx`.
- `xlrd`: dukungan tambahan untuk file `.xls` lama.
- `pytest`: automated test untuk engine klasifikasi risiko.

Library opsional jika ingin mengembangkan model lebih lanjut:

- `scikit-learn`: membuat model prediksi berbasis machine learning.
- `numpy`: komputasi numerik tambahan.
- `altair`: alternatif visualisasi deklaratif.
- `pydantic`: validasi schema input yang lebih ketat.

## Cara Menjalankan Lokal

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Jika memakai macOS/Linux:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Menyiapkan Ulang Dataset Makro

Script ini membaca file inflasi dan BI Rate dari folder `Downloads` lokal, lalu membuat `data/macro_indonesia_sample.csv`.

```bash
python scripts/prepare_macro_data.py
```

Format CSV makro yang dibutuhkan aplikasi:

```csv
year,month_num,month,inflation_mtm,bi_rate
2026,1,Januari,0.76,5.75
```

## Format CSV Transaksi

Aplikasi menerima CSV transaksi sederhana. Kolom nominal bisa bernama `amount`, `nominal`, atau `jumlah`. Kolom tipe bisa bernama `type`, `tipe`, atau `kategori`.

Contoh:

```csv
tanggal,kategori,jumlah
2026-01-01,income,8000000
2026-01-02,expense,-250000
```

## Deploy ke Streamlit Cloud

1. Push repo ke GitHub.
2. Buka [Streamlit Community Cloud](https://streamlit.io/cloud).
3. Pilih repository.
4. Set main file path: `app.py`.
5. Deploy.

Streamlit Cloud adalah target paling direkomendasikan untuk project ini karena app memakai Python, `pandas`, dan komponen `st.metric`, `st.slider`, serta `st.data_editor`.

## Deploy ke Vercel

Vercel tidak ideal untuk Streamlit native. Jika tetap ingin memakai Vercel, opsi yang lebih cocok adalah:

- ubah frontend ke Next.js dan pindahkan engine ke API route Python/Node, atau
- deploy Streamlit di layanan lain lalu embed/link dari halaman Vercel.

Untuk versi saat ini, gunakan Streamlit Cloud agar deployment langsung jalan.

## Push ke GitHub

```bash
git init
git add .
git commit -m "Initial Econo-Shield bankruptcy predictor"
git branch -M main
git remote add origin https://github.com/USERNAME/econo-shield.git
git push -u origin main
```

## Catatan Risiko

Econo-Shield adalah decision-support tool, bukan nasihat keuangan profesional. Klasifikasi didasarkan pada aturan transparan dan input pengguna, sehingga hasil harus dibaca sebagai indikator awal untuk membantu evaluasi.
